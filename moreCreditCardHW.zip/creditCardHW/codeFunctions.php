<?php
function redirect()
{
    if (empty($_POST)) {
        header("Location: index.php");
    }
}

function authenticated($username, $password)
{
    return $username == $password && $username != "" && $password != "";
}
function check_input($input)
{
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

function check_card($cNum)
{
    if ((strlen($cNum) == 16) and (in_array(substr($cNum, 0, 2), array("51", "52", "53", "54", "55")))) {
        return ["MASTERCARD", substr($cNum, -4, 4)];
    } elseif (((strlen($cNum) == 13) or (strlen($cNum) == 16)) and (substr($cNum, 0, 1) == "4")) {
        return ["VISA", substr($cNum, -4, 4)];
    } elseif ((strlen($cNum) == 15) and (in_array(substr($cNum, 0, 2), array("34", "37")))) {
        return ["AMEX", substr($cNum, -4, 4)];
    } else {
        return ["<p>Your card is invaild.</p>"];
    }
}