<?php
session_start();
require "codeFunctions.php";
redirect();

$_SESSION["item1"] = (int) $_POST['item1'] * 5;
$_SESSION["item2"] = (int) $_POST['item2'] * 7;
$_SESSION["item3"] = (int) $_POST['item3'] * 150;

$_SESSION['sub'] = $_SESSION["item1"] + $_SESSION["item2"] + $_SESSION["item3"];
?>
<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
    <h1>Order Summary</h1>
    <p>Your subtotal: $<?= $_SESSION["sub"] ?></p>
    <form method="post" action="calcPage.php">
        <p>
            <input type="submit" name="next" value="Next &gt;">
        </p>
    </form>
</body>

</html>