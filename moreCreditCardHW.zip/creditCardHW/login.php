<?php
session_start();
require "codeFunctions.php";

if (!isset($_SESSION["total"])) {
    header("Location:index.php");
}
?>
<!DOCTYPE HTML>
<html>

<head>
    <meta charset="utf-8">
    <title></title>
</head>

<body>
    <h1> Login: </h1>
    <form method="post" action="cardPage.php">
        Username: <input type="text" name="username" required> <br>
        Password: <input type="password" name="password" required> <br>
        <input type="submit">
    </form>
</body>

</html>