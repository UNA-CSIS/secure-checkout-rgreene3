<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
    <form method="post" action="ordSum.php">
        <p>
            <label for="item1">Phone Cord:</label>
            <input type="number" name="item1" id="item1">
            $5.00
        </p>
        <p>
            <label for="item2">Mug:</label>
            <input type="number" name="item2" id="item2">
            $7.00
        </p>
        <p>
            <label for="item3">Microwave:</label>
            <input type="number" name="item3" id="item3">
            $150.00
        </p>
        <p>
            <input type="submit" name="next" value="Next &gt;">
        </p>
    </form>
</body>

</html>