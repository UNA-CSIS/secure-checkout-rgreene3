<?php
session_start();
require "codeFunctions.php";
redirect();

$username = check_input($_POST["username"]);
$password = check_input($_POST["password"]);

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
    <?php
    if (authenticated($username, $password)) {
        ?>
        <h1>Checkout</h1>
        <p>Amount to Charge: $<?= $_SESSION["total"] ?></p>
        <form method="post" action="messPage.php">
            <p>
                <label for="name">Name on Card:</label>
                <input type="text" name="name" id="name" required>
            </p>
            <p>
                <label for="cNum">Card Number:</label>
                <input type="text" name="cNum" id="cNum" required>
            </p>
            <p>
                <label for="eDate">Expiration Date:</label>
                <input type="month" name="eDate" id="eDate" required pattern="[0-9]{4}-[0-9]{2}">
            </p>
            <p>
                <label for="secCode">Security Code:</label>
                <input type="password" name="secCode" id="secCode" required>
            </p>
            <p>
                <input type="submit" name="next" value="Next &gt;">
            </p>
        </form>
    <?php } else { ?>
        <p>Username or Password is Incorrect.</p>
        <p><a href="login.php">Try Again</a></p>
    <?php } ?>
</body>

</html>