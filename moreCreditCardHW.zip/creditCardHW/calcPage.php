<?php
session_start();
require "codeFunctions.php";
redirect();

// al tax 4.0%, fl tax 4.5%
$_SESSION["tax"] = round($_SESSION["sub"] * .095, 2);
$_SESSION["total"] = $_SESSION["sub"] + $_SESSION["tax"];


?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
</head>

<body>

    <p>Your subtotal: $<?= $_SESSION["sub"] ?></p>
    <p>Tax: $<?= $_SESSION["tax"] ?> </p>
    <p>Your total: $<?= $_SESSION["total"] ?></p>
    <a href="index.php">Continue Shopping</a>
    <a href="login.php">Checkout</a>
</body>

</html>