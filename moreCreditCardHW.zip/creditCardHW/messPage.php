<?php
session_start();
require "codeFunctions.php";
redirect();

$name = check_input($_POST["name"]);
$cNum = check_input($_POST["cNum"]);
$secCode = check_input($_POST["secCode"]);
?>
<!DOCTYPE html>
<html>

<head>
   <meta charset="UTF-8">
   <title></title>
</head>

<body>
   <?php
   if (strlen($secCode) == 3 && ctype_digit($secCode)) {
      $answer = check_card($cNum);
      if (count($answer) == 1) {
         echo $answer[0];
         session_destroy();
      } else {
         echo "<p>Your " . $answer[0] . " card ending in " . $answer[1] . " was charged: $" . $_SESSION["total"] . "</p>";
         session_destroy();
      }
   } else {
      echo "<p>Something was wrong with your input!</p>";
      session_destroy();
   }


   ?>
   <p><a href="index.php">Go buy more things!</a></p>
</body>

</html>